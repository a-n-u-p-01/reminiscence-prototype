import React, { useState, useEffect, useRef } from 'react';
import { Eye, CheckCircle2, ShieldAlert, Smile, Frown, Layers } from 'lucide-react';
import { noteService } from '../api/noteService';

export default function ReviewScreen({
  concepts = [],
  loading,
  onSyncNeeded,
  onCardReviewed
}) {
  const [showAnswer, setShowAnswer] = useState(false);
  const [submittingRating, setSubmittingRating] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  // References for strategic mobile element focusing
  const cardTopRef = useRef(null);
  const headerRef = useRef(null);

  const activeCard = concepts[0];

  // Automatically scroll back up into view whenever the active card changes
  useEffect(() => {
    if (activeCard && headerRef.current) {
      headerRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [concepts[0]?.userConceptId]);

  if (loading) {
    return (
      <div className="min-h-[350px] flex flex-col items-center justify-center text-zinc-500 font-mono text-xs gap-3 animate-pulse">
        <span className="h-5 w-5 border-2 border-zinc-800 border-t-blue-500 rounded-full animate-spin" />
        <span className="tracking-wider text-zinc-400">Compiling active review queue...</span>
      </div>
    );
  }

  if (!concepts || concepts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center text-center py-24 px-6 space-y-4 max-w-sm mx-auto animate-[fadeIn_0.2s_ease-out]">
        <div className="p-4 bg-emerald-500/10 rounded-full border border-emerald-500/20 shadow-lg shadow-emerald-500/5">
          <CheckCircle2 size={32} className="text-emerald-400" />
        </div>
        <div className="space-y-1">
          <h2 className="text-lg font-semibold tracking-tight text-zinc-100">
            Review Queue Cleared
          </h2>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Your memory baselines are secure. No concept cards are due right now.
          </p>
        </div>
      </div>
    );
  }

  const handleRevealAnswer = () => {
    setShowAnswer(true);
    // Forces viewport tracking to snap straight to the top section line (viewing queue)
    setTimeout(() => {
      headerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 40);
  };

  const handleRateCard = async (rating) => {
    if (submittingRating || isExiting) return;

    setSubmittingRating(true);

    try {
      await noteService.submitReviewFeedback(activeCard.userConceptId, rating);
      setIsExiting(true);

      setTimeout(() => {
        onCardReviewed(activeCard.userConceptId);
        setShowAnswer(false);
        setIsExiting(false);

        if (concepts.length === 1) {
          onSyncNeeded();
        }
      }, 150);

    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingRating(false);
    }
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.15s_ease-out]">
      
      {/* Dynamic Header Utility Panel */}
      <div 
        ref={headerRef} 
        className="flex justify-between items-start border-b border-zinc-800/60 pb-4 scroll-mt-6"
      >
        <div>
          <h1 className="text-xl font-bold tracking-tight text-zinc-500 flex items-center gap-2">
            <Layers size={18} className="text-blue-500" /> 
            <span className="text-zinc-100">Recall Active Engine</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">Active retention tracking loop.</p>
        </div>

        <span className="text-xs font-mono bg-zinc-900/50 text-blue-400 font-semibold px-2.5 py-1 rounded-full border border-zinc-800 shadow-sm">
          Queue: {concepts.length}
        </span>
      </div>

      {/* Main Flashcard Container */}
      <div 
        ref={cardTopRef}
        key={activeCard?.userConceptId}
        className={`bg-zinc-900/40 border border-zinc-800 rounded-2xl p-6 min-h-[340px] flex flex-col justify-between shadow-2xl relative transition-all duration-200 ease-in-out ${
          isExiting 
            ? 'opacity-0 scale-[0.97] translate-y-2 blur-[2px]' 
            : 'opacity-100 scale-100 translate-y-0'
        }`}
      >
        
        {/* Card Header Category Badges */}
        <div className="flex justify-between items-center border-b border-zinc-800/40 pb-4">
          <span className="text-xs font-bold tracking-wider text-blue-400 uppercase font-mono bg-blue-500/5 px-2 py-0.5 rounded border border-blue-500/10">
            {activeCard?.name || 'Concept Unit'}
          </span>

          <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border tracking-wide uppercase ${
            activeCard?.difficulty === 'HARD'
              ? 'bg-red-500/10 text-red-400 border-red-500/20'
              : activeCard?.difficulty === 'MEDIUM'
              ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
              : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
          }`}>
            {activeCard?.difficulty || 'NORMAL'}
          </span>
        </div>

        {/* Core Flashcard Text Content */}
        <div className="py-8 flex-1 flex flex-col justify-center space-y-5">
          <div className="space-y-1.5">
            <span className="text-[10px] font-bold tracking-widest font-mono text-zinc-500 uppercase block">
              Core Question
            </span>
            <p className="text-base text-zinc-100 leading-relaxed font-medium">
              {activeCard?.questionText}
            </p>
          </div>

          {showAnswer && (
            <div className="space-y-4 pt-5 border-t border-zinc-800/40 animate-[fadeIn_0.2s_ease-out]">
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold tracking-widest font-mono text-emerald-400 uppercase block">
                  Verified Resolution Answer
                </span>
                <p className="text-sm text-zinc-200 leading-relaxed bg-zinc-950/80 p-4 rounded-xl border border-zinc-800 font-mono shadow-inner whitespace-pre-wrap">
                  {activeCard?.answerText}
                </p>
              </div>

              {activeCard?.keyNotes && (
                <div className="space-y-1.5 bg-zinc-800/10 border border-zinc-800/30 p-3 rounded-xl">
                  <span className="text-[10px] font-bold tracking-widest font-mono text-zinc-500 uppercase block">
                    Contextual Key Notes
                  </span>
                  <p className="text-xs text-zinc-400 leading-relaxed italic">
                    {activeCard.keyNotes}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Multi-mode Controller Footer */}
        <div className="pt-4 border-t border-zinc-800/40">
          {!showAnswer ? (
            <button
              onClick={handleRevealAnswer}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/10 hover:shadow-blue-500/20"
            >
              <Eye size={15} /> Reveal Resolution Map
            </button>
          ) : (
            <div className="space-y-4 animate-[fadeIn_0.15s_ease-out]">
              <div className="text-center space-y-0.5">
                <span className="text-[10px] font-bold font-mono text-zinc-400 uppercase tracking-wider">
                  Rate your recall to advance queue
                </span>
                <span className="text-[10px] text-zinc-500 block">
                  Your selection recalibrates the spaced repetition schedule.
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <button
                  disabled={submittingRating || isExiting}
                  onClick={() => handleRateCard('HARD')}
                  className="bg-zinc-900 border border-red-500/20 hover:border-red-500/40 text-red-400 py-3 rounded-xl text-xs font-semibold flex flex-col items-center gap-1.5 transition-all active:scale-[0.97] disabled:opacity-40 hover:bg-red-500/5 shadow-md"
                >
                  <ShieldAlert size={15} />
                  <span>Forgot</span>
                </button>

                <button
                  disabled={submittingRating || isExiting}
                  onClick={() => handleRateCard('MEDIUM')}
                  className="bg-zinc-900 border border-amber-500/20 hover:border-amber-500/40 text-amber-400 py-3 rounded-xl text-xs font-semibold flex flex-col items-center gap-1.5 transition-all active:scale-[0.97] disabled:opacity-40 hover:bg-amber-500/5 shadow-md"
                >
                  <Frown size={15} />
                  <span>Hesitant</span>
                </button>

                <button
                  disabled={submittingRating || isExiting}
                  onClick={() => handleRateCard('EASY')}
                  className="bg-zinc-900 border border-emerald-500/20 hover:border-emerald-500/40 text-emerald-400 py-3 rounded-xl text-xs font-semibold flex flex-col items-center gap-1.5 transition-all active:scale-[0.97] disabled:opacity-40 hover:bg-emerald-500/5 shadow-md"
                >
                  <Smile size={15} />
                  <span>Got It</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}